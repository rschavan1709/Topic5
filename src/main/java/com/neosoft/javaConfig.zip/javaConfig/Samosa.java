package com.springcore.javaConfig;

public class Samosa {

	public void display() {
		System.out.println("Samosa");
	}
}
